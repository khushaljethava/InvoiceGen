This is a very simple and old calculator that do basic calculations.
